package com.test.app.entity;

public class PropertyEntity {

	private String name;
	
	private String type;
	
	public PropertyEntity() {
		super();
	}

	public PropertyEntity(String name, String propertyType) {
		super();
		this.name = name;
		this.type = propertyType;
	}

	public String getName() {
		return name;
	}

	public void setPropertyName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
