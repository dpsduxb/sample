package com.test.app.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.PojoTemplateTest;
import com.test.app.entity.PropertyEntity;
import com.test.app.repository.MongoBean;

@RestController
@RequestMapping("/collections")
public class MongoCollectionController {
	
	
	@Autowired
	private MongoBean mongoBean;

	@GetMapping("/collections")
	public Map<String, Set<PropertyEntity>> getAllCollDocProp(){
		Set<String> collNames = mongoBean.mongoDBBean().getCollectionNames();
		
		HashMap<String, Set<PropertyEntity>> collProps = new HashMap<String, Set<PropertyEntity>>();
		for (Iterator iterator = collNames.iterator(); iterator.hasNext();) {
			String collName = (String) iterator.next();
			
			collProps.put(collName, getDocumentProperties(collName));
		}
		
		return collProps;
	}
	
	@GetMapping("/genProj")
	public Boolean generateMS(){
		Map<String, Set<PropertyEntity>> docProps = getAllCollDocProp();
		
		PojoTemplateTest pojoTemplateTest = new PojoTemplateTest();
		pojoTemplateTest.generateMSProj(docProps);
		return false;
	}
	
	@GetMapping("/all")
	public Set<String> getAllCollections(){
		return mongoBean.mongoDBBean().getCollectionNames();
	}
	
	@GetMapping("/{colName}")
	public Map getCollectionDocument(@NotEmpty @PathVariable("colName") String colName){
		return mongoBean.mongoDBBean().getCollection(colName).findOne().toMap();
	}
	
	@GetMapping("/prop/{colName}")
	public Set<PropertyEntity> getDocumentProperties(@NotEmpty @PathVariable("colName") String colName){
		Map docProps = mongoBean.mongoDBBean().getCollection(colName).findOne().toMap();
		Set<PropertyEntity> docPropTypes = new HashSet<>();
		docProps.forEach((k,v)->{
			if(!k.toString().equalsIgnoreCase("_class")){
				if(k.toString().startsWith("_")){
					docPropTypes.add(new PropertyEntity(k.toString().substring(1), propertyType(v)));
				}else{
					docPropTypes.add(new PropertyEntity(k.toString(), propertyType(v)));
				}
			}
		});
		
		return docPropTypes;
	}
	
	private String propertyType(Object value){
		String propType = "";
		if (value instanceof String) {
			propType = "String";
		} else if (value instanceof Boolean) {
			propType = "Boolean";
		} else if (value instanceof Number) {
			propType = "Number";
		} else if (value instanceof Integer) {
			propType = "Interger";
		} else if (value instanceof Date) {
			propType = "Date";
		} else if (value instanceof List) {
			propType = "List";
		} else {
			propType = "String";
		}
		
		return propType;
	}
	
}
