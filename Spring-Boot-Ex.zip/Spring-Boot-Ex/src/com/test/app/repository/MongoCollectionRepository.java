package com.test.app.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.test.app.entity.PropertyEntity;

public interface MongoCollectionRepository extends MongoRepository<PropertyEntity, String>{

}
