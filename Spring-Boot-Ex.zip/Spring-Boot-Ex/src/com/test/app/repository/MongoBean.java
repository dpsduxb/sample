package com.test.app.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;

import com.mongodb.DB;

@Configuration
public class MongoBean {
	
	private final MongoDbFactory mongo;
	
	@Autowired
	public MongoBean(MongoDbFactory mongo){
		this.mongo = mongo;
	}
	
	@Bean
	public DB mongoDBBean(){
		return mongo.getDb();
	}
	
}
