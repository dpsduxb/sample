package com.olive.hrd.controller;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olive.hrd.entity.ResultEntity;
import com.olive.hrd.repository.ResultRepository;

@RestController
@RequestMapping("/results")
public class ResultController {
	
	@Autowired
	private ResultRepository repository;

	@GetMapping("/all")
	public List<ResultEntity> getAllResults(){
		return repository.findAll();
	}
	
	@GetMapping("/{resultId}")
	public ResultEntity getresultId(@NotEmpty @PathVariable("resultId") String resultId){
		return repository.findOne(resultId);
	}
	
	@PostMapping("/add")
	public void saveResult (@RequestBody ResultEntity resultEntity){
		repository.save( resultEntity );
	}
	
	@PutMapping("/{resultId}")
	public void updateResult (@NotEmpty @PathVariable("resultId") String resultId, @RequestBody ResultEntity resultEntity){
		repository.save( resultEntity );
	}
	
	@DeleteMapping("/{resultId}")
	public void deleteResult (@NotEmpty @PathVariable("resultId") String resultId){
		repository.delete(resultId);
	}
}
