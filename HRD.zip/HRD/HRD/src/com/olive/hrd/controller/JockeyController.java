package com.olive.hrd.controller;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olive.hrd.entity.JockeyEntity;
import com.olive.hrd.repository.JockeyRepository;

@RestController
@RequestMapping("/jockeys")
public class JockeyController {
	
	@Autowired
	private JockeyRepository repository;

	@GetMapping("/all")
	public List<JockeyEntity> getAllJockeys(){
		return repository.findAll();
	}
	
	@GetMapping("/{jockeyId}")
	public JockeyEntity getjockeyId(@NotEmpty @PathVariable("jockeyId") String jockeyId){
		return repository.findOne(jockeyId);
	}
	
	@PostMapping("/add")
	public void saveJockey (@RequestBody JockeyEntity jockeyEntity){
		repository.save( jockeyEntity );
	}
	
	@PutMapping("/{jockeyId}")
	public void updateJockey (@NotEmpty @PathVariable("jockeyId") String jockeyId, @RequestBody JockeyEntity jockeyEntity){
		repository.save( jockeyEntity );
	}
	
	@DeleteMapping("/{jockeyId}")
	public void deleteJockey (@NotEmpty @PathVariable("jockeyId") String jockeyId){
		repository.delete(jockeyId);
	}
}
