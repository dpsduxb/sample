package com.olive.hrd.controller;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olive.hrd.entity.HorseEntity;
import com.olive.hrd.repository.HorseRepository;

@RestController
@RequestMapping("/horses")
public class HorseController {
	
	@Autowired
	private HorseRepository repository;

	@GetMapping("/all")
	public List<HorseEntity> getAllHorses(){
		return repository.findAll();
	}
	
	@GetMapping("/{horseId}")
	public HorseEntity gethorseId(@NotEmpty @PathVariable("horseId") String horseId){
		return repository.findOne(horseId);
	}
	
	@PostMapping("/add")
	public void saveHorse (@RequestBody HorseEntity horseEntity){
		repository.save( horseEntity );
	}
	
	@PutMapping("/{horseId}")
	public void updateHorse (@NotEmpty @PathVariable("horseId") String horseId, @RequestBody HorseEntity horseEntity){
		repository.save( horseEntity );
	}
	
	@DeleteMapping("/{horseId}")
	public void deleteHorse (@NotEmpty @PathVariable("horseId") String horseId){
		repository.delete(horseId);
	}
}
