package com.olive.hrd.controller;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olive.hrd.entity.DividendEntity;
import com.olive.hrd.repository.DividendRepository;

@RestController
@RequestMapping("/dividends")
public class DividendController {
	
	@Autowired
	private DividendRepository repository;

	@GetMapping("/all")
	public List<DividendEntity> getAllDividends(){
		return repository.findAll();
	}
	
	@GetMapping("/{dividendId}")
	public DividendEntity getdividendId(@NotEmpty @PathVariable("dividendId") String dividendId){
		return repository.findOne(dividendId);
	}
	
	@PostMapping("/add")
	public void saveDividend (@RequestBody DividendEntity dividendEntity){
		repository.save( dividendEntity );
	}
	
	@PutMapping("/{dividendId}")
	public void updateDividend (@NotEmpty @PathVariable("dividendId") String dividendId, @RequestBody DividendEntity dividendEntity){
		repository.save( dividendEntity );
	}
	
	@DeleteMapping("/{dividendId}")
	public void deleteDividend (@NotEmpty @PathVariable("dividendId") String dividendId){
		repository.delete(dividendId);
	}
}
