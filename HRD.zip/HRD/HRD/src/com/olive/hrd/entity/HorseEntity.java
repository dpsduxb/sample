package com.olive.hrd.entity;

import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "horse")
public class HorseEntity {

	public HorseEntity() {
		super();
	}
	
public HorseEntity( String DistanceThird, String TrainerCode, String LifeTotalRuns, String DistanceTotalRuns, String HorseNo, String BodyWeight, String MeetingDate, String id, String JockeyCode, String DistanceFirst, String LastHorseWeight, String RaceNo, String LastSixRecords, String Draw, String LifeFirst, String Distance, String DistanceSecond, String ClassChange, String HorseCode, String Condition, String Age, String LastSixRunTxt, String Comment, String IdealDistance, String RunningStyleAll, String LifeThird, String Ability, String MeetingVenue, String HorseWeight, String LifeSecond, String WeightCarried ) {
	super();
		this.DistanceThird = DistanceThird;
		this.TrainerCode = TrainerCode;
		this.LifeTotalRuns = LifeTotalRuns;
		this.DistanceTotalRuns = DistanceTotalRuns;
		this.HorseNo = HorseNo;
		this.BodyWeight = BodyWeight;
		this.MeetingDate = MeetingDate;
		this.id = id;
		this.JockeyCode = JockeyCode;
		this.DistanceFirst = DistanceFirst;
		this.LastHorseWeight = LastHorseWeight;
		this.RaceNo = RaceNo;
		this.LastSixRecords = LastSixRecords;
		this.Draw = Draw;
		this.LifeFirst = LifeFirst;
		this.Distance = Distance;
		this.DistanceSecond = DistanceSecond;
		this.ClassChange = ClassChange;
		this.HorseCode = HorseCode;
		this.Condition = Condition;
		this.Age = Age;
		this.LastSixRunTxt = LastSixRunTxt;
		this.Comment = Comment;
		this.IdealDistance = IdealDistance;
		this.RunningStyleAll = RunningStyleAll;
		this.LifeThird = LifeThird;
		this.Ability = Ability;
		this.MeetingVenue = MeetingVenue;
		this.HorseWeight = HorseWeight;
		this.LifeSecond = LifeSecond;
		this.WeightCarried = WeightCarried;
	}
	
	private String DistanceThird;
	private String TrainerCode;
	private String LifeTotalRuns;
	private String DistanceTotalRuns;
	private String HorseNo;
	private String BodyWeight;
	private String MeetingDate;
	private String id;
	private String JockeyCode;
	private String DistanceFirst;
	private String LastHorseWeight;
	private String RaceNo;
	private String LastSixRecords;
	private String Draw;
	private String LifeFirst;
	private String Distance;
	private String DistanceSecond;
	private String ClassChange;
	private String HorseCode;
	private String Condition;
	private String Age;
	private String LastSixRunTxt;
	private String Comment;
	private String IdealDistance;
	private String RunningStyleAll;
	private String LifeThird;
	private String Ability;
	private String MeetingVenue;
	private String HorseWeight;
	private String LifeSecond;
	private String WeightCarried;

	public void setDistanceThird (String DistanceThird){
		this.DistanceThird = DistanceThird;
	}
	
	public String getDistanceThird () {
		return this.DistanceThird;
	}
	public void setTrainerCode (String TrainerCode){
		this.TrainerCode = TrainerCode;
	}
	
	public String getTrainerCode () {
		return this.TrainerCode;
	}
	public void setLifeTotalRuns (String LifeTotalRuns){
		this.LifeTotalRuns = LifeTotalRuns;
	}
	
	public String getLifeTotalRuns () {
		return this.LifeTotalRuns;
	}
	public void setDistanceTotalRuns (String DistanceTotalRuns){
		this.DistanceTotalRuns = DistanceTotalRuns;
	}
	
	public String getDistanceTotalRuns () {
		return this.DistanceTotalRuns;
	}
	public void setHorseNo (String HorseNo){
		this.HorseNo = HorseNo;
	}
	
	public String getHorseNo () {
		return this.HorseNo;
	}
	public void setBodyWeight (String BodyWeight){
		this.BodyWeight = BodyWeight;
	}
	
	public String getBodyWeight () {
		return this.BodyWeight;
	}
	public void setMeetingDate (String MeetingDate){
		this.MeetingDate = MeetingDate;
	}
	
	public String getMeetingDate () {
		return this.MeetingDate;
	}
	public void setid (String id){
		this.id = id;
	}
	
	public String getid () {
		return this.id;
	}
	public void setJockeyCode (String JockeyCode){
		this.JockeyCode = JockeyCode;
	}
	
	public String getJockeyCode () {
		return this.JockeyCode;
	}
	public void setDistanceFirst (String DistanceFirst){
		this.DistanceFirst = DistanceFirst;
	}
	
	public String getDistanceFirst () {
		return this.DistanceFirst;
	}
	public void setLastHorseWeight (String LastHorseWeight){
		this.LastHorseWeight = LastHorseWeight;
	}
	
	public String getLastHorseWeight () {
		return this.LastHorseWeight;
	}
	public void setRaceNo (String RaceNo){
		this.RaceNo = RaceNo;
	}
	
	public String getRaceNo () {
		return this.RaceNo;
	}
	public void setLastSixRecords (String LastSixRecords){
		this.LastSixRecords = LastSixRecords;
	}
	
	public String getLastSixRecords () {
		return this.LastSixRecords;
	}
	public void setDraw (String Draw){
		this.Draw = Draw;
	}
	
	public String getDraw () {
		return this.Draw;
	}
	public void setLifeFirst (String LifeFirst){
		this.LifeFirst = LifeFirst;
	}
	
	public String getLifeFirst () {
		return this.LifeFirst;
	}
	public void setDistance (String Distance){
		this.Distance = Distance;
	}
	
	public String getDistance () {
		return this.Distance;
	}
	public void setDistanceSecond (String DistanceSecond){
		this.DistanceSecond = DistanceSecond;
	}
	
	public String getDistanceSecond () {
		return this.DistanceSecond;
	}
	public void setClassChange (String ClassChange){
		this.ClassChange = ClassChange;
	}
	
	public String getClassChange () {
		return this.ClassChange;
	}
	public void setHorseCode (String HorseCode){
		this.HorseCode = HorseCode;
	}
	
	public String getHorseCode () {
		return this.HorseCode;
	}
	public void setCondition (String Condition){
		this.Condition = Condition;
	}
	
	public String getCondition () {
		return this.Condition;
	}
	public void setAge (String Age){
		this.Age = Age;
	}
	
	public String getAge () {
		return this.Age;
	}
	public void setLastSixRunTxt (String LastSixRunTxt){
		this.LastSixRunTxt = LastSixRunTxt;
	}
	
	public String getLastSixRunTxt () {
		return this.LastSixRunTxt;
	}
	public void setComment (String Comment){
		this.Comment = Comment;
	}
	
	public String getComment () {
		return this.Comment;
	}
	public void setIdealDistance (String IdealDistance){
		this.IdealDistance = IdealDistance;
	}
	
	public String getIdealDistance () {
		return this.IdealDistance;
	}
	public void setRunningStyleAll (String RunningStyleAll){
		this.RunningStyleAll = RunningStyleAll;
	}
	
	public String getRunningStyleAll () {
		return this.RunningStyleAll;
	}
	public void setLifeThird (String LifeThird){
		this.LifeThird = LifeThird;
	}
	
	public String getLifeThird () {
		return this.LifeThird;
	}
	public void setAbility (String Ability){
		this.Ability = Ability;
	}
	
	public String getAbility () {
		return this.Ability;
	}
	public void setMeetingVenue (String MeetingVenue){
		this.MeetingVenue = MeetingVenue;
	}
	
	public String getMeetingVenue () {
		return this.MeetingVenue;
	}
	public void setHorseWeight (String HorseWeight){
		this.HorseWeight = HorseWeight;
	}
	
	public String getHorseWeight () {
		return this.HorseWeight;
	}
	public void setLifeSecond (String LifeSecond){
		this.LifeSecond = LifeSecond;
	}
	
	public String getLifeSecond () {
		return this.LifeSecond;
	}
	public void setWeightCarried (String WeightCarried){
		this.WeightCarried = WeightCarried;
	}
	
	public String getWeightCarried () {
		return this.WeightCarried;
	}
	
}
