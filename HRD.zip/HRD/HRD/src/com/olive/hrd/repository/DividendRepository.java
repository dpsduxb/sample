package com.olive.hrd.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.olive.hrd.entity.DividendEntity;

public interface DividendRepository extends MongoRepository<DividendEntity, String>{

}
