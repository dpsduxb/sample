package com.olive.hrd.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.olive.hrd.entity.JockeyEntity;

public interface JockeyRepository extends MongoRepository<JockeyEntity, String>{

}
