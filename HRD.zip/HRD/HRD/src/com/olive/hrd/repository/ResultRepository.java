package com.olive.hrd.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.olive.hrd.entity.ResultEntity;

public interface ResultRepository extends MongoRepository<ResultEntity, String>{

}
