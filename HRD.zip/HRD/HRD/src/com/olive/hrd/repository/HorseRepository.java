package com.olive.hrd.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.olive.hrd.entity.HorseEntity;

public interface HorseRepository extends MongoRepository<HorseEntity, String>{

}
